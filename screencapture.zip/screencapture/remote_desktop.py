import asyncio
import json
import random
import string
import tkinter as tk
from tkinter import messagebox, ttk
import websockets
from aiortc import RTCPeerConnection, RTCConfiguration, RTCIceServer, RTCSessionDescription, RTCIceCandidate, RTCDataChannel
from aiortc.contrib.media import MediaPlayer, MediaStreamTrack
import threading
import os
import pyautogui
import socket
from collections import defaultdict

# Configure pyautogui
pyautogui.FAILSAFE = False  # Disable failsafe for remote control
pyautogui.PAUSE = 0  # Minimize input delay

# Global rooms dictionary
rooms = defaultdict(list)

# Generate random 8-character code
def generate_code():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))

# Custom VideoStreamTrack for screen sharing
class ScreenShareTrack(MediaStreamTrack):
    kind = "video"

    def __init__(self):
        super().__init__()
        self.player = MediaPlayer('desktop', format='gdigrab' if os.name == 'nt' else 'x11grab')

    async def recv(self):
        frame = await self.player.video.recv()
        return frame

# Check and free port if in use
def free_port(port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("localhost", port))
        sock.close()
    except socket.error as e:
        if e.errno == 10048:  # Port in use (Windows)
            print(f"Port {port} is in use, attempting to free it...")
            import psutil
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    for conn in proc.connections():
                        if conn.laddr.port == port:
                            print(f"Terminating process {proc.pid} ({proc.name()}) using port {port}")
                            proc.terminate()
                            proc.wait(timeout=3)
                            break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            # Try binding again
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("localhost", port))
            sock.close()

# WebSocket server for signaling
async def run_server():
    port = 8765
    try:
        free_port(port)
        async def handler(websocket):
            try:
                async for message in websocket:
                    data = json.loads(message)
                    room = data.get('room')

                    if data['type'] == 'join':
                        rooms[room].append(websocket)
                        print(f"Client joined room {room}")

                    elif data['type'] == 'request-connect':
                        for client in rooms[room]:
                            if client != websocket:
                                await client.send(json.dumps({'type': 'confirm-connect', 'from': id(websocket)}))

                    elif data['type'] == 'confirm':
                        for client in rooms[room]:
                            if id(client) == data['to']:
                                await client.send(json.dumps({'type': 'confirmed', 'confirmed': data['confirmed']}))
                                break

                    elif data['type'] in ['offer', 'answer', 'candidate']:
                        for client in rooms[room]:
                            if client != websocket:
                                await client.send(message)
            except websockets.exceptions.ConnectionClosed:
                for room, clients in list(rooms.items()):
                    if websocket in clients:
                        clients.remove(websocket)
                        break

        server = await websockets.serve(handler, "localhost", port)
        print(f"Server running on ws://localhost:{port}")
        await server.wait_closed()
    except Exception as e:
        print(f"Failed to start server: {e}")
        raise

# GUI Application
class RemoteDesktopApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Remote Desktop App")
        self.root.geometry("400x300")
        self.root.resizable(False, False)
        self.root.configure(bg="#f0f0f0")

        self.pc = None
        self.ws = None
        self.room = None
        self.stream = None
        self.data_channel = None

        # Create a new event loop for async tasks
        self.loop = asyncio.new_event_loop()
        self.async_thread = threading.Thread(target=self.run_loop, daemon=True)
        self.async_thread.start()

        # Styling
        self.style = ttk.Style()
        self.style.configure("TButton", font=("Helvetica", 12), padding=10)
        self.style.configure("TLabel", font=("Helvetica", 12), background="#f0f0f0")
        self.style.configure("TEntry", font=("Helvetica", 12))

        # Main frame
        self.frame = ttk.Frame(self.root, padding=20)
        self.frame.pack(fill="both", expand=True)

        # Title
        self.title_label = ttk.Label(self.frame, text="Remote Desktop", font=("Helvetica", 16, "bold"))
        self.title_label.pack(pady=10)

        # Mode selection
        self.host_btn = ttk.Button(self.frame, text="Start as Host", command=self.start_host)
        self.host_btn.pack(pady=5, fill="x")

        self.viewer_btn = ttk.Button(self.frame, text="Start as Viewer", command=self.start_viewer)
        self.viewer_btn.pack(pady=5, fill="x")

        # Code display/input
        self.code_frame = ttk.Frame(self.frame)
        self.code_label = ttk.Label(self.code_frame, text="Room Code:")
        self.code_label.pack(side="left")
        self.code_display = ttk.Label(self.code_frame, text="", font=("Helvetica", 12, "bold"))
        self.code_display.pack(side="left", padx=10)
        self.code_entry = ttk.Entry(self.code_frame, width=15)
        self.code_entry.pack(side="left", padx=10)
        self.join_btn = ttk.Button(self.code_frame, text="Join", command=self.join_room)
        self.join_btn.pack(side="left")
        self.code_frame.pack(pady=10, fill="x")

        # Status
        self.status_label = ttk.Label(self.frame, text="Status: Idle", foreground="blue")
        self.status_label.pack(pady=10)

        # Start server in background
        self.server_thread = threading.Thread(target=lambda: asyncio.run(run_server()), daemon=True)
        self.server_thread.start()

    def run_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def update_status(self, message, color="blue"):
        self.status_label.config(text=f"Status: {message}", foreground=color)

    def start_host(self):
        self.host_btn.config(state="disabled")
        self.viewer_btn.config(state="disabled")
        self.code_entry.pack_forget()
        self.join_btn.pack_forget()
        self.room = generate_code()
        self.code_display.config(text=self.room)
        asyncio.run_coroutine_threadsafe(self.run_host(), self.loop)
        self.update_status("Hosting, share code: " + self.room, "green")

    def start_viewer(self):
        self.host_btn.config(state="disabled")
        self.viewer_btn.config(state="disabled")
        self.code_display.pack_forget()
        self.code_entry.pack(side="left", padx=10)
        self.join_btn.pack(side="left")
        self.update_status("Enter room code to join", "blue")

    def join_room(self):
        self.room = self.code_entry.get().strip()
        if not self.room:
            messagebox.showerror("Error", "Please enter a valid room code.")
            return
        self.code_entry.config(state="disabled")
        self.join_btn.config(state="disabled")
        asyncio.run_coroutine_threadsafe(self.run_viewer(self.room), self.loop)
        self.update_status("Requesting connection...", "orange")

    async def run_host(self):
        self.pc = RTCPeerConnection(RTCConfiguration(iceServers=[RTCIceServer(urls="stun:stun.l.google.com:19302")]))
        self.ws = await websockets.connect('ws://localhost:8765')

        # Create data channel for input events
        self.data_channel = self.pc.createDataChannel("input")
        @self.data_channel.on("message")
        def on_message(message):
            data = json.loads(message)
            if data['type'] == 'mouse_move':
                pyautogui.moveTo(data['x'], data['y'])
            elif data['type'] == 'mouse_click':
                pyautogui.click(button=data['button'])
            elif data['type'] == 'key_press':
                pyautogui.press(data['key'])

        # Share screen
        track = ScreenShareTrack()
        self.stream = track.player
        self.pc.addTrack(track)

        @self.pc.on("track")
        def on_track(track):
            print("Receiving remote track:", track.kind)

        async def send_message(msg):
            await self.ws.send(json.dumps({**msg, 'room': self.room}))

        # Join room
        await send_message({'type': 'join'})

        # Handle incoming messages
        async def handle_messages():
            try:
                async for message in self.ws:
                    data = json.loads(message)
                    if data['type'] == 'confirm-connect':
                        self.root.after(0, lambda: self.confirm_connection(data['from']))
                    elif data['type'] == 'offer':
                        await self.pc.setRemoteDescription(RTCSessionDescription(sdp=data['sdp'], type=data['sdp_type']))
                        answer = await self.pc.createAnswer()
                        await self.pc.setLocalDescription(answer)
                        await send_message({'type': 'answer', 'sdp': answer.sdp, 'sdp_type': answer.type})
                    elif data['type'] == 'candidate':
                        await self.pc.addIceCandidate(RTCIceCandidate(**data['candidate']))
            except websockets.exceptions.ConnectionClosed:
                self.root.after(0, lambda: self.update_status("Disconnected", "red"))

        @self.pc.on("icecandidate")
        async def on_icecandidate(event):
            if event.candidate:
                await send_message({'type': 'candidate', 'candidate': event.candidate.to_dict()})

        await asyncio.gather(handle_messages())

    def confirm_connection(self, viewer_id):
        confirmed = messagebox.askyesno("Connection Request", "Are you sure you want them to connect?")
        asyncio.run_coroutine_threadsafe(
            self.ws.send(json.dumps({'type': 'confirm', 'to': viewer_id, 'confirmed': confirmed, 'room': self.room})),
            self.loop
        )
        if not confirmed:
            self.update_status("Connection denied", "red")

    async def run_viewer(self, room):
        self.pc = RTCPeerConnection(RTCConfiguration(iceServers=[RTCIceServer(urls="stun:stun.l.google.com:19302")]))
        self.ws = await websockets.connect('ws://localhost:8765')

        @self.pc.on("datachannel")
        def on_datachannel(channel):
            self.data_channel = channel
            @self.data_channel.on("open")
            def on_open():
                print("Data channel opened for input")

        @self.pc.on("track")
        def on_track(track):
            self.root.after(0, lambda: self.update_status("Connected, receiving screen", "green"))
            # Note: Video display requires a GUI video widget (not implemented due to Tkinter limitations)

        # Capture mouse and keyboard events
        def on_mouse_move(event):
            if self.data_channel and self.data_channel.readyState == "open":
                x, y = event.x_root, event.y_root
                self.data_channel.send(json.dumps({'type': 'mouse_move', 'x': x, 'y': y}))

        def on_mouse_click(event):
            if self.data_channel and self.data_channel.readyState == "open":
                button = 'left' if event.num == 1 else 'right'
                self.data_channel.send(json.dumps({'type': 'mouse_click', 'button': button}))

        def on_key_press(event):
            if self.data_channel and self.data_channel.readyState == "open":
                key = event.keysym
                self.data_channel.send(json.dumps({'type': 'key_press', 'key': key}))

        self.root.bind('<Motion>', on_mouse_move)
        self.root.bind('<Button-1>', on_mouse_click)
        self.root.bind('<Button-3>', on_mouse_click)
        self.root.bind('<KeyPress>', on_key_press)

        async def send_message(msg):
            await self.ws.send(json.dumps({**msg, 'room': room}))

        # Join room and request connection
        await send_message({'type': 'join'})
        await send_message({'type': 'request-connect'})

        # Handle incoming messages
        async def handle_messages():
            try:
                async for message in self.ws:
                    data = json.loads(message)
                    if data['type'] == 'confirmed':
                        if data['confirmed']:
                            offer = await self.pc.createOffer()
                            await self.pc.setLocalDescription(offer)
                            await send_message({'type': 'offer', 'sdp': offer.sdp, 'sdp_type': offer.type})
                            self.root.after(0, lambda: self.update_status("Connecting...", "orange"))
                        else:
                            self.root.after(0, lambda: messagebox.showerror("Error", "Connection denied by host."))
                            self.root.after(0, lambda: self.update_status("Connection denied", "red"))
                            await self.ws.close()
                            break
                    elif data['type'] == 'answer':
                        await self.pc.setRemoteDescription(RTCSessionDescription(sdp=data['sdp'], type=data['sdp_type']))
                    elif data['type'] == 'candidate':
                        await self.pc.addIceCandidate(RTCIceCandidate(**data['candidate']))
            except websockets.exceptions.ConnectionClosed:
                self.root.after(0, lambda: self.update_status("Disconnected", "red"))

        @self.pc.on("icecandidate")
        async def on_icecandidate(event):
            if event.candidate:
                await send_message({'type': 'candidate', 'candidate': event.candidate.to_dict()})

        await asyncio.gather(handle_messages())

def main():
    root = tk.Tk()
    app = RemoteDesktopApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()